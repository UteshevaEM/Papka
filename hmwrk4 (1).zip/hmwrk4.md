

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

url = 'https://raw.githubusercontent.com/vaibhavwalvekar/NYC-Flights-2013-Dataset-Analysis/master/flights.csv'    
flights = pd.read_csv(url, sep = ',')
flights.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>year</th>
      <th>month</th>
      <th>day</th>
      <th>dep_time</th>
      <th>dep_delay</th>
      <th>arr_time</th>
      <th>arr_delay</th>
      <th>carrier</th>
      <th>tailnum</th>
      <th>flight</th>
      <th>origin</th>
      <th>dest</th>
      <th>air_time</th>
      <th>distance</th>
      <th>hour</th>
      <th>minute</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>517.0</td>
      <td>2.0</td>
      <td>830.0</td>
      <td>11.0</td>
      <td>UA</td>
      <td>N14228</td>
      <td>1545</td>
      <td>EWR</td>
      <td>IAH</td>
      <td>227.0</td>
      <td>1400</td>
      <td>5.0</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>533.0</td>
      <td>4.0</td>
      <td>850.0</td>
      <td>20.0</td>
      <td>UA</td>
      <td>N24211</td>
      <td>1714</td>
      <td>LGA</td>
      <td>IAH</td>
      <td>227.0</td>
      <td>1416</td>
      <td>5.0</td>
      <td>33.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>542.0</td>
      <td>2.0</td>
      <td>923.0</td>
      <td>33.0</td>
      <td>AA</td>
      <td>N619AA</td>
      <td>1141</td>
      <td>JFK</td>
      <td>MIA</td>
      <td>160.0</td>
      <td>1089</td>
      <td>5.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>544.0</td>
      <td>-1.0</td>
      <td>1004.0</td>
      <td>-18.0</td>
      <td>B6</td>
      <td>N804JB</td>
      <td>725</td>
      <td>JFK</td>
      <td>BQN</td>
      <td>183.0</td>
      <td>1576</td>
      <td>5.0</td>
      <td>44.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>554.0</td>
      <td>-6.0</td>
      <td>812.0</td>
      <td>-25.0</td>
      <td>DL</td>
      <td>N668DN</td>
      <td>461</td>
      <td>LGA</td>
      <td>ATL</td>
      <td>116.0</td>
      <td>762</td>
      <td>5.0</td>
      <td>54.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>554.0</td>
      <td>-4.0</td>
      <td>740.0</td>
      <td>12.0</td>
      <td>UA</td>
      <td>N39463</td>
      <td>1696</td>
      <td>EWR</td>
      <td>ORD</td>
      <td>150.0</td>
      <td>719</td>
      <td>5.0</td>
      <td>54.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>555.0</td>
      <td>-5.0</td>
      <td>913.0</td>
      <td>19.0</td>
      <td>B6</td>
      <td>N516JB</td>
      <td>507</td>
      <td>EWR</td>
      <td>FLL</td>
      <td>158.0</td>
      <td>1065</td>
      <td>5.0</td>
      <td>55.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>557.0</td>
      <td>-3.0</td>
      <td>709.0</td>
      <td>-14.0</td>
      <td>EV</td>
      <td>N829AS</td>
      <td>5708</td>
      <td>LGA</td>
      <td>IAD</td>
      <td>53.0</td>
      <td>229</td>
      <td>5.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>557.0</td>
      <td>-3.0</td>
      <td>838.0</td>
      <td>-8.0</td>
      <td>B6</td>
      <td>N593JB</td>
      <td>79</td>
      <td>JFK</td>
      <td>MCO</td>
      <td>140.0</td>
      <td>944</td>
      <td>5.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>2013</td>
      <td>1</td>
      <td>1</td>
      <td>558.0</td>
      <td>-2.0</td>
      <td>753.0</td>
      <td>8.0</td>
      <td>AA</td>
      <td>N3ALAA</td>
      <td>301</td>
      <td>LGA</td>
      <td>ORD</td>
      <td>138.0</td>
      <td>733</td>
      <td>5.0</td>
      <td>58.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
url = 'https://raw.githubusercontent.com/vaibhavwalvekar/NYC-Flights-2013-Dataset-Analysis/master/weather.csv'
weather = pd.read_csv(url, sep = ',')
weather = weather.drop(columns = "year").drop(columns = "origin").drop(columns = "Unnamed: 0")
weather.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>month</th>
      <th>day</th>
      <th>hour</th>
      <th>temp</th>
      <th>dewp</th>
      <th>humid</th>
      <th>wind_dir</th>
      <th>wind_speed</th>
      <th>wind_gust</th>
      <th>precip</th>
      <th>pressure</th>
      <th>visib</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>37.04</td>
      <td>21.92</td>
      <td>53.97</td>
      <td>230.0</td>
      <td>10.35702</td>
      <td>11.918651</td>
      <td>0.0</td>
      <td>1013.9</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>37.04</td>
      <td>21.92</td>
      <td>53.97</td>
      <td>230.0</td>
      <td>13.80936</td>
      <td>15.891535</td>
      <td>0.0</td>
      <td>1013.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>37.94</td>
      <td>21.92</td>
      <td>52.09</td>
      <td>230.0</td>
      <td>12.65858</td>
      <td>14.567241</td>
      <td>0.0</td>
      <td>1012.6</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
      <td>37.94</td>
      <td>23.00</td>
      <td>54.51</td>
      <td>230.0</td>
      <td>13.80936</td>
      <td>15.891535</td>
      <td>0.0</td>
      <td>1012.7</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>4.0</td>
      <td>37.94</td>
      <td>24.08</td>
      <td>57.04</td>
      <td>240.0</td>
      <td>14.96014</td>
      <td>17.215830</td>
      <td>0.0</td>
      <td>1012.8</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>6.0</td>
      <td>39.02</td>
      <td>26.06</td>
      <td>59.37</td>
      <td>270.0</td>
      <td>10.35702</td>
      <td>11.918651</td>
      <td>0.0</td>
      <td>1012.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>7.0</td>
      <td>39.02</td>
      <td>26.96</td>
      <td>61.63</td>
      <td>250.0</td>
      <td>8.05546</td>
      <td>9.270062</td>
      <td>0.0</td>
      <td>1012.3</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>8.0</td>
      <td>39.02</td>
      <td>28.04</td>
      <td>64.43</td>
      <td>240.0</td>
      <td>11.50780</td>
      <td>13.242946</td>
      <td>0.0</td>
      <td>1012.5</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>9.0</td>
      <td>39.92</td>
      <td>28.04</td>
      <td>62.21</td>
      <td>250.0</td>
      <td>12.65858</td>
      <td>14.567241</td>
      <td>0.0</td>
      <td>1012.2</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>10.0</td>
      <td>39.02</td>
      <td>28.04</td>
      <td>64.43</td>
      <td>260.0</td>
      <td>12.65858</td>
      <td>14.567241</td>
      <td>0.0</td>
      <td>1011.9</td>
      <td>10.0</td>
    </tr>
  </tbody>
</table>
</div>



 # 1. Cредняя задержка рейсов по месяцам и зависимость от осадков


```python
plt.plot(flights[flights['origin']=='EWR'].groupby('month')['dep_delay'].mean(),color='green',label='EWR')
plt.plot(flights[flights['origin']=='LGA'].groupby('month')['dep_delay'].mean(),color='red',label='LGA')
plt.plot(flights[flights['origin']=='JFK'].groupby('month')['dep_delay'].mean(),color='orange',label='JFK')
W=(weather.groupby('month')['precip'].mean())*5000
plt.plot(W,color='blue', ls='dashed', label='осадки')

plt.legend()
plt.title("Средняя задержка отправки рейса по месяцам")
plt.xlabel("Месяц")
plt.ylabel("Среднее значение задержки")
plt.xticks(np.arange(1,13))
plt.show()
```


![png](output_3_0.png)


Вывод: Осадки играют важную роль в задержке рейсов. В зависимости от прогноза погоды стоит готовиться к бОльшим задержкам. Наибольшее время задержек приходится на лето, наименьшее - на осень.

# 2. Зависимость средней задержки от времени суток


```python
depE=flights[flights['origin']=='EWR'].groupby('hour')['dep_delay'].mean()
depL=flights[flights['origin']=='LGA'].groupby('hour')['dep_delay'].mean()
depJ=flights[flights['origin']=='JFK'].groupby('hour')['dep_delay'].mean()
arrE=flights[flights['origin']=='EWR'].groupby('hour')['arr_delay'].mean()
arrL=flights[flights['origin']=='LGA'].groupby('hour')['arr_delay'].mean()
arrJ=flights[flights['origin']=='JFK'].groupby('hour')['arr_delay'].mean()
plt.plot(depE,color='red',ls='dashed',label='Отправка EWR')
plt.plot(depL,color='green',ls='dashed',label='Отправка LGA')
plt.plot(depJ,color='blue',ls='dashed',label='Отправка JFK')
plt.plot(arrE,color='red',label='Прибытие EWR')
plt.plot(arrL,color='green',label='Прибытие LGA')
plt.plot(arrJ,color='blue',label='Прибытие JFK')
plt.xticks(np.arange(25))
plt.title("Средняя задержка")
plt.xlabel("Час")
plt.ylabel("Среднее время")
plt.legend()
plt.show()
```


![png](output_6_0.png)


Вывод: Наихудшее время - интервал с 22 до 5 часов, то есть ночное время. Возможные причины - темнота, усталость, меньшее количесиво персонала.

# 3. Зависимость от дальности полета.


```python
plt.plot(flights.groupby('arr_delay')['air_time'].mean(),'o',color='red',label='LGA')
plt.title("Средняя задержка в зависимости от расстояния")
plt.xlabel("Задержка")
plt.ylabel("Время полета")
plt.show()
```


![png](output_9_0.png)



```python
plt.plot(flights[flights['distance']<1000].groupby('arr_delay')['distance'].mean(),'o',color='red',label='LGA')
plt.plot(flights[flights['distance']>3000].groupby('arr_delay')['distance'].mean(),'o',color='blue',label='LGA')
plt.title("Средняя задержка рейсов на малое и большое расстояние")
plt.xlabel("Задержка")
plt.ylabel("Расстояние")
plt.show()
```


![png](output_10_0.png)


Вывод: При полетах на маленькие расстояния задержек больше, чем при полете на дальние, средняя задержках на дальних меньше.

# 4. Среднее значение задержки во всех аэропортах.


```python
A=flights['dep_delay'].reset_index()
len0=len(A)
len1=len(A[A['dep_delay']<0])
len2=len(A[A['dep_delay']>30])
x=np.zeros(len0)
y=np.zeros(len0)
x[:len1]=100/len0
y[:len2]=100/len0
labels='Без задержки','Более получаса', 'Менее получаса'
plt.pie([x.sum(),y.sum(),100-x.sum()-y.sum()],labels=labels,autopct='%1.1f%%')
plt.title("Задержки вылета")
plt.show()
```


![png](output_13_0.png)



```python
A=flights['arr_delay'].reset_index()
len0=len(A)
len1=len(A[A['arr_delay']<0])
len2=len(A[A['arr_delay']>30])
x=np.zeros(len0)
y=np.zeros(len0)
x[:len1]=100/len0
y[:len2]=100/len0
labels='Без задержки','Более получаса', 'Менее получаса'
plt.pie([x.sum(),y.sum(),100-x.sum()-y.sum()],labels=labels,autopct='%1.1f%%')
plt.title("Задержки прибытия")
plt.show()
```


![png](output_14_0.png)


Вывод: Распределение прибытий и задержек примерно одинаково. К сожалению, задержка есть почти у половины рейсов, и около 30% из них - более получаса.

# 5. Зависимость от влажности воздуха.


```python
mer = flights.merge(weather)
plt.scatter(mer.groupby(['month','day'])['humid'].mean(), mer.groupby(['month','day'])['dep_delay'].mean()[0:500], color = 'aqua')
plt.title('Зависимость времени задержек вылета от влажности')
plt.xlabel('Влажность')
plt.ylabel('Задержка')

```




    Text(0, 0.5, 'Задержка')




![png](output_17_1.png)


Вывод: Чем выше влажность, тем большее время задержки. Значит, влажность -  один из важных факторов, на который стоит обратить внимание.

# 6. Сравнение задержек в аэропортах


```python
plt.figure(figsize=(6,3))
B=flights[flights.dep_delay > 0].groupby('origin')['dep_delay'].mean()
plt.subplot(1,2,1)
plt.bar(np.arange(3), B, color='pink')
plt.xticks(np.arange(3),  ('EWR','JFK','LGA'))
plt.title("Задержка")
plt.xlabel("Аэропорт")
plt.ylabel("Среднее значение задержки")
С=(flights[flights.dep_delay < 0].groupby('origin')['dep_delay'].mean())*(-1)
plt.subplot(1,2,2)
plt.bar(np.arange(3), С, color='khaki')
plt.xticks(np.arange(3),  ('EWR','JFK','LGA'))
plt.title("Опережение графика")
plt.xlabel("Аэропорт")
plt.show()

```


![png](output_20_0.png)


Вывод: JFK - наиболее надежный аэропорт с наименьшими отклонениями от графика, LGA - чаще других опережает график, но и больше отстает. 

# 7. Наиболее надежные и наиболее проблемные перевозчики.


```python
fl_delay=flights[flights.dep_delay>0]
A1=pd.DataFrame(flights.groupby([flights.carrier]).size().reset_index(name='Total_Count'))
A2=pd.DataFrame(fl_delay.groupby([fl_delay.carrier]).size().reset_index(name='Count'))
fl_merged = pd.merge(A1, A2, on=['carrier'])
fl_merged['Percent'] = (fl_merged.Count/fl_merged.Total_Count)*100
plt.bar(np.arange(len(fl_merged.carrier)), fl_merged.Percent, color="sandybrown")
plt.xlabel('Перевозчики')
plt.ylabel('Процент')
plt.title('Процент задержек от перевозчика')
plt.xticks(np.arange(len(fl_merged.carrier)), fl_merged.carrier)
plt.show()
```


![png](output_23_0.png)


Вывод: На этом графике мы видим, какие перевозчики более ответственны (HA, US), а на какие нужно обратить внимание и постараться уменьшить их задержки (WN, FL, F9).

# 8. Меняют ли праздничные дни показатели?


```python
fl_dec=flights[flights.month==12]
fl_chr=fl_dec[fl_dec.day==25].groupby('hour')['dep_delay'].mean()
fl_jun=flights[flights.month==6]
fl_day=fl_jun[fl_jun.day==2].groupby('hour')['dep_delay'].mean()
fl_nov=flights[flights.month==11]
fl_thx=fl_nov[fl_nov.day==28].groupby('hour')['dep_delay'].mean()
fl_avg=flights[flights.month==8]
fl_day2=fl_avg[fl_avg.day==8].groupby('hour')['dep_delay'].mean()
plt.plot(fl_chr,color='goldenrod',alpha=0.7,label='Опоздание в Рождество')
plt.plot(fl_thx,color='lightcoral',alpha=0.7,label='Опоздание в День Благодарения')

plt.plot(fl_day,color='indigo',alpha=0.7,label='Опоздание в обычный день #1')
plt.plot(fl_day2,color='darkcyan',alpha=0.7,label='Опоздание в обычный день #2')
plt.xticks(np.arange(25))
plt.title("Средняя задержка")
plt.xlabel("Час")
plt.ylabel("Среднее время")
plt.legend()
plt.show()
```


![png](output_26_0.png)


Вывод: В праздничные дни задержка, в целом, меньше, чем в обычные дни. Возможно, в праздники меньше людей летают, возможно, в праздники компании более ответственно относятся к перевозкам. Более того, мы видим, что наибольшая разница вечером и ночью.

# 9. Влияние видимости на задержки.


```python
plt.plot(flights.groupby('month')['dep_delay'].mean(),color='olive',label='delay')
W=(weather.groupby('month')['visib'].mean())
plt.plot(W,color='orchid', label='видимость')
plt.legend()
plt.title("Средняя задержка и значение видимости по месяцам")
plt.xlabel("Месяц")
plt.ylabel("Среднее значение задержки")
plt.xticks(np.arange(1,13))
plt.show()
```


![png](output_29_0.png)


Видим, что в целом зависимость не наблюдается.
Но здесь данные сильно усреднены, возьмем какой-нибудь конкретный день, в который видимость менялась и попробуем проанализировать.


```python
fl_jun=flights[flights.month==6]
fl_day=fl_jun[fl_jun.day==3].groupby('hour')['dep_delay'].mean()
w_jun=weather[weather.month==6.0]
w_day=w_jun[w_jun.day==3.0].groupby('hour')['visib'].mean()
plt.plot(fl_day,color='olive',alpha=0.7,label='Опоздание 3 июня')
plt.plot(w_day,color='orchid', label='Видимость 3 июня')
plt.legend()
plt.title("Средняя задержка и значение видимости по месяцам")
plt.xlabel("Месяц")
plt.ylabel("Среднее значение задержки")
plt.xticks(np.arange(1,24))
plt.show()
```


![png](output_31_0.png)


Вывод: здесь мы видим, что с ухудшением видимости с 10 до 14 часов, поднялось и время задержек. Но в целом, зависимость не такая явная. Таким образом, видимость - важный фактор, но совсем не основной.

# 10. Зависимость задержек от ветра.


```python
plt.figure(figsize=(16,3))
B=flights[flights.month ==11].groupby('day')['dep_delay'].mean()
W=weather[weather.month ==11].groupby('day')['wind_speed'].mean()
WG=weather[weather.month ==11].groupby('day')['wind_gust'].mean()

plt.subplot(1,2,1)
plt.bar(np.arange(30), B, alpha=0.5, color='midnightblue', label = 'Задержка')
plt.xticks(np.arange(30))
plt.ylabel("Среднее значение")
plt.bar(np.arange(30),W, alpha=0.5,color='darkorchid', label = 'Ветер')
plt.legend()
plt.xticks(np.arange(30))
plt.title("Скорость ветра")
plt.xlabel("День")

plt.figure(figsize=(16,3))
plt.subplot(1,2,2)
plt.bar(np.arange(30), B, alpha=0.5, color='mediumvioletred',  label = 'Задержка')
plt.xticks(np.arange(30))
plt.ylabel("Среднее значение")
plt.bar(np.arange(30),WG, alpha=0.5,color='royalblue', label = 'Ветер')
plt.xticks(np.arange(30))
plt.title("Порывы ветра")
plt.xlabel("День")
plt.legend()
plt.show()
```


![png](output_34_0.png)



![png](output_34_1.png)


Вывод: ни скорость ветра, ни порывы ветра существенно не влияют на задержки ресов. Я взяла конкретный месяц - ноябрь, чтобы внимательнее наблюдать зависимость.


```python

```


```python

```


```python

```


```python

```


```python

```
